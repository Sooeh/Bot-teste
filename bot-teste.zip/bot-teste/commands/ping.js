const { SlashCommandBuilder } = require('discord.js')

module.exports = {
   data: new SlashCommandBuilder()
     .setName("ping")
     .setDescription("Comando teste"),

   async execute(insteraction) {
     await InteractionType.reply("Pong!")
  }
}