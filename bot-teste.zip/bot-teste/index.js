


const { Client, Events, GatewayIntentBits, Collection } = require('discord.js');
//dotev
const dotenv = require('dotenv')
dotenv.config()
const { TOKEN, CLIENT_ID, GUILD_ID } = process.env

//importar cmds
const fs = require("fs")
const path = require("path")

const commandsPath = path.join(__dirname, "commands")
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith(".js"))
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
client.commands = new Collection()

for (const file of commandFiles){
	const filePath = path.join(commandsPath, file)
	const command = require(filePath)
	if ("data" in command && "execute" in command){
       client.commands.set(command.data.name, command)
	} else {
		console.log(`Este comando em ${filePath} está com "data ou "execute" ausentes`)
	}
}



client.once(Events.ClientReady, readyClient => {
	console.log(`Ready! Logged in as ${readyClient.user.tag}`);
});

client.login(TOKEN);

// listener 
client.on(Events.InterationCreate, async interation => {
	if(!interation.isChatInputCommand()) return
	const command = interation.client.commands.get(interation.commandName)
	if (!command) {
		console.error("Comando Não encontrado:(")
		return
	}
	try {
		await command.execute(interation)
	}
	catch (error) {
        console.error(error)
		await interation.reply("Houve um erro ao executar o comando.")
	}
})