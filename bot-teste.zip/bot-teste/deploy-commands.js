const { REST, Routes } = require("discord.js")

//dotev
const dotenv = require('dotenv')
dotenv.config()
const { TOKEN, CLIENT_ID, GUILD_ID } = process.env
//importar cmds
const fs = require("fs")
const path = require("path")

const commandsPath = path.join(__dirname, "commands")
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith(".js"))

const commands = [];

for (const file of commandFiles) {
    const command = require(`./commands/${file}`)
    commands.push(command.data.toJSON())
}

const rest = new REST({version: "10"}).setToken(TOKEN);

// and deploy your commands!
(async () => {
	try {
		console.log(`Resetando ${commands.length} comandos...`)

		// The put method is used to fully refresh all commands in the guild with the current set
		const data = await rest.put(
			Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
			{ body: commands })
            
            console.log(`Comandos registrados com sucesso.`)

	} catch (error) {
		// And of course, make sure you catch and log any errors!
		console.error(error);
	}
})()